define([], function() {
  return {
    "Title": "BiomarinCssApplicationCustomizer"
  }
});