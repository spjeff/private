declare interface IBiomarinCssApplicationCustomizerStrings {
  Title: string;
}

declare module 'BiomarinCssApplicationCustomizerStrings' {
  const strings: IBiomarinCssApplicationCustomizerStrings;
  export = strings;
}
