define([], function() {
  return {
    "Title": "BiomarinCss2ApplicationCustomizer"
  }
});