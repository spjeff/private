declare interface IBiomarinCss2ApplicationCustomizerStrings {
  Title: string;
}

declare module 'BiomarinCss2ApplicationCustomizerStrings' {
  const strings: IBiomarinCss2ApplicationCustomizerStrings;
  export = strings;
}
