﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;
using System.Web.Http.Cors;

namespace RotaryTravelAPI.Controllers
{
    public class TravelRequestController : ApiController
    {

        [EnableCors(origins: "*",
    headers: "*",
    methods: "*",
    SupportsCredentials = true)]

        private bool IsSecure()
        {

            // security HTTP header
            string key = "VWco7wDsB#RXIn7Dnu(LIjE55Nv43i_UVHBU5vYYRNln";
            IEnumerable<string> headerValues;
            var keyFilter = string.Empty;
            if (Request.Headers.TryGetValues("key", out headerValues))
            {
                // ALLOW - match key
                keyFilter = headerValues.FirstOrDefault();
            }
            if (keyFilter == key)
            {
                return true;
            }
            else
            {
                return false;
            }

        }

        // GET api/values
        public string[] Get()
        {
            if (this.IsSecure())
            {
                DateTime now = DateTime.Now;
                return new string[] { "Hello", now.ToLongDateString() + " " + now.ToLongTimeString() };
            }
            else
            {
                return null;
            }
        }


        // POST api/values
        public async Task<HttpResponseMessage> Post([FromBody] string body)
        {
            if (this.IsSecure())
            {
                // MS Login
                RotaryToken token = await GetToken();
                string access_token = token.access_token;

                // MS Graph
                return CreateSPListItem(body, access_token);
            }
            else
            {
                return null;
            }
        }


        // from https://stackoverflow.com/questions/5665558/c-sharp-httpwebrequest-of-type-application-x-www-form-urlencoded-how-to-send
        // from https://stackoverflow.com/questions/53529061/whats-the-right-way-to-use-httpclient-synchronously
        public static async Task<RotaryToken> GetToken()
        {
            using (var httpClient = new HttpClient())
            {
                // from http://ronaldrosiernet.azurewebsites.net/Blog/2013/12/07/posting_urlencoded_key_values_with_httpclient
                var keyValues = new List<KeyValuePair<string, string>>();
                keyValues.Add(new KeyValuePair<string, string>("grant_type", "client_credentials"));
                keyValues.Add(new KeyValuePair<string, string>("client_id", "9bb5d45a-6aa3-4006-a395-ce8397e48baa"));
                keyValues.Add(new KeyValuePair<string, string>("client_secret", ".Uws6Gndx3~c6YyxEd-L~2a_3GPTL_cPWi"));
                keyValues.Add(new KeyValuePair<string, string>("scope", "https://graph.microsoft.com/.default"));

                using (var content = new FormUrlEncodedContent(keyValues))
                {
                    // Headers
                    content.Headers.Clear();
                    content.Headers.Add("Content-Type", "application/x-www-form-urlencoded");

                    // Add SPListItem
                    //var siteId = "d4cad0de-2ea8-401a-bffc-bcac059af874";
                    //var listId = "7b275616-c383-425c-b42c-2bfde9ed80a1";
                    //var url = "https://graph.microsoft.com/v1.0/sites/" + siteId + "/lists/" + listId + "/items";

                    var tenantName = "spjeff.com";
                    var url = "https://login.microsoftonline.com/" + tenantName + "/oauth2/v2.0/token";

                    // ASync
                    // from https://stackoverflow.com/questions/45550761/convert-a-httpresponsemessage-to-an-object
                    HttpResponseMessage response = await httpClient.PostAsync(url, content);
                    var responseContent = await response.Content.ReadAsStringAsync();
                    var token = JsonConvert.DeserializeObject<RotaryToken>(responseContent);
                    return token;
                }
            }
        }

        public static HttpResponseMessage CreateSPListItem(string body, string access_token)
        {
            using (var httpClient = new HttpClient())
            {
                httpClient.DefaultRequestHeaders.Add("Authorization", "Bearer " + access_token);
                using (var content = new StringContent(body))
                {
                    // Headers
                    content.Headers.Clear();
                    content.Headers.Add("Content-Type", "application/json");
                    //content.Headers.Add("Authorization", "Bearer "+ access_token);

                    // Add SPListItem
                    var siteId = "d4cad0de-2ea8-401a-bffc-bcac059af874";
                    var listId = "7b275616-c383-425c-b42c-2bfde9ed80a1";
                    var url = "https://graph.microsoft.com/v1.0/sites/" + siteId + "/lists/" + listId + "/items";

                    // Sync
                    var task = Task.Run(() => httpClient.PostAsync(url, content));
                    task.Wait();
                    var response = task.Result;
                    return response;
                }
            }
        }


        // **
    }

}
