// from https://docs.microsoft.com/en-us/graph/api/resources/sharepoint?view=graph-rest-1.0
// from https://developer.microsoft.com/en-us/graph/blogs/controlling-app-access-on-specific-sharepoint-site-collections/
// from https://ashiqf.com/2021/03/15/how-to-use-microsoft-graph-sharepoint-sites-selected-application-permission-in-a-azure-ad-application-for-more-granular-control/

// from https://dmitripavlutin.com/replace-all-string-occurrences-javascript/
function replaceAll(string, search, replace) {
    return string.split(search).join(replace);
}

// https://stackoverflow.com/questions/3054819/get-url-parameter-function-that-gets-value-of-url-part-or-returns-true-if-its-t
function gup(name, url) {
    name = name.replace(/[\[]/, '\\\[').replace(/[\]]/, '\\\]');
    var results = new RegExp('[\\?&]' + name + '=?([^&#]*)').exec(url || window.location.href);
    return results == null ? null : results[1];
}

// from https://stackoverflow.com/questions/19254029/angularjs-http-post-does-not-send-data
Object.toparams = function ObjecttoParams(obj) {
    var p = [];
    for (var key in obj) {
        p.push(key + '=' + encodeURIComponent(obj[key]));
    }
    return p.join('&');
};

function travelCtl($scope, $http) {
    // Scope
    var vm = $scope;
    window.travelCtl = vm;

    // Globals
    vm.hello = 'world';
    vm.travelRequest = [];
    vm.arrCity = [{}];
    vm.arrDriveCity = [{}];

    // 0 first page
    vm.page = 0;
    vm.isExternal = true;
    vm.optRole = ["AF Leadership", "Aide to President", "Aid to President Elect", "Aide to President Nominee", "ARC", "ARPIC", "ARRFC", "CMTE CHR", "CMTE MBR", "DC Pres Rep", "DG", "Director", "Director Elect", "E/MGA", "Facilitator", "Fiscal Agent", "GETS Trainer", "HR Candidate", "Incoming Trustee", "Jounalist", "Liaison", "Moderator", "Other", "Past General Secretary", "Past Trustee", "Past Director", "Past President", "Peace Fellow", "RC", "RFAC", "Rep to UN", "RPIC", "RRFC", "Rotaractor", "SAA", "Scholar", "Speaker", "Training Leader", "Trustee", "Trustee Chair", "Trustee Chair Elect", "Vendor"];
    vm.optClassification = ["Volunteer", "Partner", "Program Participant", "Other"];
    vm.optTravelerType = ["AF Leadership", "Aide to President", "Aide to President-Elect", "Aide to President-Nominee", "ARC", "ARPIC", "ARRFC", "CMTE CHR", "CMTE MBR", "COL Delegate", "DC Pres Rep", "DG", "DGE", "Director", "Director Elect", "Director Nominee", "E/MGA", "Facilitator", "Fiscal Agent", "General Secretary", "GETS Trainer", "GSE", "HR Candidate", "Incoming Trustee", "Journalist", "Liaison", "Moderator", "Other", "Past General Secretary", "Past Trustee", "Past Trustee Chair", "Peace Fellow", "PRID", "PRIP", "Programs Pres Rep", "RC", "RFAC", "RI President", "RI President-Elect", "RI President-Nominee", "RI Rep to UN", "RI Training Leader", "Rotaractor", "RPIC", "RRFC", "SAA", "Scholar", "Speaker", "Trustee", "Trustee Chair", "Trustee Chair Elect", "Vendor", "ZCC"]
    vm.optAccountNumber = ["160120", "160121", "160122", "160123", "160151", "160161", "160180", "160190", "160209", "160210", "160211", "160212", "160213", "160214", "160411", "230222", "230301", "230302", "230334", "230340", "230700", "230710", "230730", "230740", "230741", "230742", "230743", "230801", "500201", "500106", "500321", "500401", "500431", "500434", "500435", "500612", "500701", "500821", "510021", "510201", "510202", "510501", "510506", "510803", "510804", "510805", "510806", "510807", "510808", "510811", "510812", "510814", "510819", "520503", "530002", "540001", "540101", "540201", "540251", "540301", "540302", "540303", "540304", "540313", "540314", "540315", "540316", "540664", "540830", "540831", "540832", "540833", "541000", "541020", "550301", "550351", "550601", "550701", "580060"];
    vm.optLiasonCostCenter = ["AA000", "BD100", "BD110", "CL100", "CM100", "CM103", "CM104", "CM105", "CM106", "CM107", "CM108", "CM109", "CM110", "CM112", "CM113", "CM117", "CM118", "CM122", "CM200", "CM203", "CM211", "CM215", "CM220", "CM230", "CM232", "CM236", "CM242", "CM252", "CM253", "CM266", "CM271", "CM274", "CM285", "CM288", "CM338", "CM360", "CM405", "CM407", "CM411", "CM412", "CM413", "CM414", "CM502", "CM503", "CM504", "CM505", "CM506", "CM507", "CM508", "CM509", "CM510", "CM511", "CM512", "CM514", "CM515", "CM516", "CM517", "CP001", "CP006", "CP002", "CP100", "CP110", "CP116", "CP120", "CP125", "CP130", "CP140", "CP150", "CP160", "CP170", "CP200", "CP300", "CP400", "CP401", "CP402", "CP403", "CP405", "CP406", "CP410", "CP412", "CP415", "CP416", "CP500", "CP515", "CP600", "CP810", "CP821", "CP824", "CP823", "CP843", "CP844", "CP845", "CP858", "CP859", "CS001", "CS002", "CS100", "CS200", "CS300", "DC110", "DG110", "DG115", "DG120", "EA100", "EA200", "EX001", "FD001", "FD100", "FD300", "FD400", "FD420", "FD500", "FD600", "FD700", "FD900", "FI001", "FI010", "FI100", "FI120", "FI130", "FI140", "FI400", "FN300", "FV200", "GA001", "GS001", "GS010", "GS100", "GS120", "GS130", "HR100", "HR101", "IA100", "IC100", "IC110", "IC120", "LS001", "MB001", "MC200", "MD001", "MD002", "MD100", "MD200", "MD300", "MI001", "MI002", "MI100", "MI111", "MI122", "MI150", "MI200", "MI211", "MI255", "MI300", "MI355", "MI400", "MS003", "MS004", "MS006", "MS007", "MS020", "MS021", "MS022", "MS023", "MS024", "MS025", "MS026", "MS070", "MS200", "MS210", "MS220", "MS230", "MS240", "MS300", "MS310", "MS330", "MS500", "OS001", "OS100", "OS105", "OS120", "OS210", "OS220", "OS230", "OS240", "OS300", "OS410", "OS430", "OS510", "PC100", "PC900", "PG100", "PG150", "PG200", "PG300", "PM100", "PO100", "PO200", "PO400", "PO500", "PP100", "PP140", "PP300", "PP302", "PP311", "PP320", "PP330", "PP340", "PP342", "PP343", "PP344", "RF001", "RF020", "RF030", "RF035", "RF031", "RF032", "RF033", "RF034", "RF038", "RF039", "RF040", "RF057", "RF086", "RF099", "RF100", "RF110", "RF130", "RF144", "RF151", "RF161", "RF175", "RF180", "RF200", "RF205", "RF210", "RF220", "RF230", "RF251", "RF271", "RF294", "RF295", "RF296", "RF297", "RF300", "RF301", "RF302", "RF303", "RF304", "RF306", "RF307", "RF315", "RF325", "RF335", "RF345", "RF355", "RF392", "RF400", "RF401", "RF402", "RF403", "RF404", "RF405", "RF406", "RF407", "RF409", "RF419", "RF420", "RF421", "RF500", "RF550", "RF600", "RF620", "RF630", "RF650", "RF651", "RF655", "RF665", "RF700", "SC001", "SC320", "SP001", "SP100", "SP101", "SP200", "SP300"];
    vm.optAffiliateOffice = ["BR", "IN", "JP", "KR", "NZ", "PH", "US"];


    // Read Only volunteer fields
    vm.disableInternal = function () {
        return !vm.isExternal;
    }


    // Default Item
    vm.item = {
        Title: '.'
    };

    // Page 8 - Depart City
    vm.addCity = function () {
        var temp = {
            DepartCity: '',
            DestCity: '',
            DepartDate: '',
        };
        vm.arrCity.push(temp);
    };
    vm.addDriveCity = function () {
        var temp = {
            DepartCity: '',
            DestCity: '',
            DepartDate: '',
        };
        vm.arrDriveCity.push(temp);
    };

    // save all responses to SQL server
    vm.submit = function () {
        // try {

        // Clean JSON __deferred for UDPATE
        delete vm.item.AttachmentFiles;
        delete vm.item.ContentType;
        delete vm.item.FieldValuesAsHtml;
        delete vm.item.FieldValuesAsText;
        delete vm.item.FieldValuesForEdit;
        delete vm.item.File;
        delete vm.item.FirstUniqueAncestorSecurableObject;
        delete vm.item.Folder;
        delete vm.item.GetDlpPolicyTip;
        delete vm.item.ParentList;
        delete vm.item.Properties;
        delete vm.item.RoleAssignments;
        delete vm.item.Versions;
        delete vm.item.LikedByInformation



        if (!vm.isExternal) {
            // INTERNAL
            // UPDATE
            spcrud.update($http, 'TravelRequest', vm.id, vm.item).then(function (resp) {
                console.log(resp);

                // Display and Redirect
                toastr['success']('Saved Travel Request', '');
                window.setTimeout(function() {document.location.href='/Lists/TravelRequest';}, 1000);
            });
        } else {
            // EXTERNAL

            // JSON
            vm.item.JSONCity = angular.toJson(vm.arrCity);
            var body = { fields: vm.item };
            var bodyString = JSON.stringify(JSON.stringify(body));

            // Data type Float
            if (vm.item.DrivingDistance) {
                vm.item.DrivingDistance = parseFloat(vm.item.DrivingDistance);
            };

            // Add SPListItem
            var url = '/api/TravelRequest';
            $http({
                method: 'POST',
                url: url,
                data: bodyString,
                headers: {
                    'key': 'VWco7wDsB#RXIn7Dnu(LIjE55Nv43i_UVHBU5vYYRNln'
                }
            }).then(function (resp) {
                console.log(resp);
            });

            // Display Success
            toastr['success']('Saved Travel Request', '');
            vm.next();
            // } catch (ex) {
            // Display Error
            // toastr['error']('Error Travel Request : ' + ex, '');
            // }
        }
    };

    // Navigation
    vm.next = function () {
        vm.oldpage = vm.page;
        vm.page++;

        // Not Driving.  Skip page 7.
        if (vm.oldpage == 6 && vm.page == 7 && vm.item.TypeTransportation == 'Other') {
            vm.page = 8;
        }

        // Max 12 pages
        // if (vm.page > 12) {
        //     vm.page = 12;
        // }
    };

    vm.prev = function () {
        vm.oldpage = vm.page;
        vm.page--;

        // Not Driving.  Skip page 7.
        if (vm.oldpage == 8 && vm.page == 7 && vm.item.TypeTransportation == 'Other') {
            vm.page = 6;
        }

        // Max 8
        if (vm.page < 0) {
            vm.page = 0;
        }
    };

    vm.disableNext = function (page) {
        switch (page) {
            case 1:
                // code block
                return vm.item.AcceptRisks !== 'Yes';
                break;
            case 2:
                // code block
                return (!vm.item.FirstName || !vm.item.LastName || !vm.item.Nationality || !vm.item.PlanningTravel == 'Yes')
                    || (vm.item.PlanningTravel == 'Yes' && (!vm.item.CompanionFirstName || !vm.item.CompanionLastName || !vm.item.CompanionNationality || !vm.item.CompanionRotaryFunded));
                break;
            case 3:
                // code block
                return !vm.item.ContactEmail || !vm.item.ContactPhone || !vm.item.ContactMobile || !vm.item.ContactAlternatePhone || !vm.item.HomeAddress || !vm.item.HomeCity || !vm.item.HomeState || !vm.item.HomePostal || !vm.item.HomeCountry;
                break;
            case 4:
                // code block
                return !vm.item.TravelCapacity;
                break;
            case 5:
                // code block
                return !vm.item.TravelPurpose || !vm.item.AssignmentRole;
                break;
            case 6:
                // code block
                return !vm.item.TypeTransportation || (vm.item.TypeTransportation == 'Other' && !vm.item.Comments);
                break;
            case 7:
                // code block
                if (vm.item.TypeTransportation == 'Drive') {
                    // Drive
                    return (isNaN(vm.item.DrivingDistance) || !vm.item.DrivingDistance || !vm.item.DrivingDistanceUnit);
                } else if (vm.item.TypeTransportation == 'Fly') {
                    // Fly
                    return (isNaN(vm.item.DrivingDistance) || !vm.item.NearAirport || !vm.item.DrivingDistance || !vm.item.DrivingDistanceUnit);
                }

                break;
            case 8:
                // code block
                break;
            case 9:
                // code block
                return !vm.item.EmergencyContactName || !vm.item.EmergencyContactPhone || !vm.item.EmergencyContactEmail;
                break;
            case 10:
                // code block
                return (
                    (!vm.item.WhyTravelEssential || !vm.item.StaffLiasonName || !vm.item.StaffLiasonEmail)
                    || (vm.item.StaffLiasonEmail.toLowerCase().indexOf('rotary.org') == -1)
                );
                break;
            case 11:
                // code block
                break;
            default:
            // code block
        }
    };

    // from https://stackoverflow.com/questions/43017887/using-nan-with-condition
    vm.isNaN = function (value) {
        return isNaN(value);
    };

    // Refresh on load
    vm.init = function () {
        // Page internal user
        if (window['_spPageContextInfo']) {
            vm.isExternal = false;


        }

        // Read SPUID parameter
        vm.id = gup('SPID');
        if (vm.id) {
            // READ
            spcrud.readItem($http, 'TravelRequest', vm.id).then(function (resp) {
                // Read item JSON
                vm.item = resp.data.d;

                if (!vm.item.RITSApproved) {
                    // Travel Services
                    vm.page = 12;
                } else {
                    // Staff Liason
                    vm.page = 13;
                }

                vm.$apply();
            });
        } 
    };
    vm.init();
}

angular.module('travelApp', [])
    .controller('travelCtl', travelCtl);
