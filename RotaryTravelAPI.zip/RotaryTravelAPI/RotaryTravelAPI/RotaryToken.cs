﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;

namespace RotaryTravelAPI.Controllers
{
    public class RotaryToken
    {
        public string access_token;
    }
}